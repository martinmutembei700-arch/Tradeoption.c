# TradeOption

A simple paper-trading website using $10,000 of virtual money.

## Files
- index.html
- style.css
- script.js

## Important
This is a simulation. It does not place real trades or use real money.

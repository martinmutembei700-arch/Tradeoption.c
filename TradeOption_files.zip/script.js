const stocks=[
 {s:"AAPL",name:"Apple",price:227.00},
 {s:"MSFT",name:"Microsoft",price:512.00},
 {s:"NVDA",name:"NVIDIA",price:180.00},
 {s:"TSLA",name:"Tesla",price:450.00},
 {s:"AMZN",name:"Amazon",price:230.00},
 {s:"GOOGL",name:"Alphabet",price:250.00}
];

let cash=10000;
let holdings={};

function money(n){return "$"+n.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});}

function render(){
  document.getElementById("stocks").innerHTML=stocks.map((x,i)=>`
    <div class="stock">
      <h3>${x.s}</h3><div>${x.name}</div>
      <div class="price">${money(x.price)}</div>
      <button class="buy" onclick="trade(${i},1)">Buy 1</button>
      <button class="sell" onclick="trade(${i},-1)">Sell 1</button>
    </div>`).join("");

  let value=0;
  Object.entries(holdings).forEach(([s,q])=>{
    const x=stocks.find(a=>a.s===s); value+=x.price*q;
  });
  document.getElementById("cash").textContent=money(cash);
  document.getElementById("portfolio").textContent=money(cash+value);
  document.getElementById("pl").textContent=money(cash+value-10000);

  const entries=Object.entries(holdings).filter(([,q])=>q>0);
  document.getElementById("holdings").innerHTML=entries.length?entries.map(([s,q])=>{
    const x=stocks.find(a=>a.s===s);
    return `<div class="holding"><span><b>${s}</b> — ${q} share(s)</span><span>${money(q*x.price)}</span></div>`;
  }).join(""):"No positions yet.";
}

function trade(i,dir){
  const x=stocks[i];
  if(dir===1){
    if(cash<x.price){alert("Not enough virtual cash.");return;}
    cash-=x.price; holdings[x.s]=(holdings[x.s]||0)+1;
  }else{
    if(!holdings[x.s]){alert("You don't own this stock.");return;}
    cash+=x.price; holdings[x.s]--;
  }
  render();
}
render();
